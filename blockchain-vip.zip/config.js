module.exports = {
    host: '192.168.84.44',
    port: '8090',
    publicPath: '',
    vendors: [
        'babel-polyfill',
        'axios',
        'layui-layer'
    ]
}
