module.exports = {
    host: '192.168.84.43',
    port: '8060',
    publicPath: '',
    vendors: [
        'babel-polyfill',
        'axios',
        'layui-layer'
    ]
}
